SELECT COUNT(*) FROM ratings where rating = 10;
