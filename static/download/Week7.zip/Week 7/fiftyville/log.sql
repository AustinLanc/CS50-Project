-- Keep a log of any SQL queries you execute as you solve the mystery.
SELECT description
    FROM crime_scene_reports
    WHERE year = 2023
    AND month = 7
    AND day = 28
    AND street = 'Humphrey Street'; --General start to look for leads on the date of the crime
SELECT name, transcript
    FROM interviews
    WHERE year = 2023
    AND month = 7
    AND day = 28; --Info from witnesses to get clues, only ones that pertain to the crime are relevant
SELECT caller, receiver
    FROM phone_calls
    WHERE year = 2023
    AND month = 7
    AND day = 28
    AND duration < 60; --List of possible phone numbers for thiefs
SELECT license_plate, hour, minute
    FROM bakery_security_logs
    WHERE year = 2023
    AND month = 7
    AND day = 28
    AND activity = 'exit'
    AND hour = 10
    AND minute BETWEEN 15 AND 25; --List of possible license plates for the thief
SELECT name
    FROM people
    WHERE license_plate IN
        (SELECT license_plate
        FROM bakery_security_logs
        WHERE year = 2023
        AND month = 7
        AND day = 28
        AND activity = 'exit'
        AND hour = 10
        AND minute BETWEEN 15 AND 25)
    AND (phone_number IN
        (SELECT caller
        FROM phone_calls
        WHERE year = 2023
        AND month = 7
        AND day = 28
        AND duration < 60)); --Leaving at right time and made <1 min phone call
SELECT account_number, amount
    FROM atm_transactions
    WHERE account_number IN
        (SELECT account_number
        FROM bank_accounts
        WHERE person_id IN
            (SELECT id
            FROM people
            WHERE license_plate IN
                (SELECT license_plate
                FROM bakery_security_logs
                WHERE year = 2023 AND month = 7
                AND day = 28 AND activity = 'exit'
                AND hour = 10
                AND minute BETWEEN 15 AND 25)
            AND (phone_number IN
                (SELECT caller
                FROM phone_calls
                WHERE year = 2023
                AND month = 7
                AND day = 28
                AND duration < 60))))
    AND atm_location = 'Leggett Street'
    AND transaction_type = 'withdraw'; --Withdrawals for potential suspects
SELECT name, id
    FROM people
    WHERE id IN
        (SELECT person_id
        FROM bank_accounts
        WHERE account_number = 49610011); --Bruce most likely suspect, had 2 withdrawls at correct atm location, left bakery at right time, made call for correct length
SELECT receiver
    FROM phone_calls
    WHERE caller IN
        (SELECT phone_number
        FROM people
        WHERE name = 'Bruce')
    AND year = 2023
    AND month = 7
    AND day = 28
    AND duration < 60; --Call that matches up Receiver: (375) 555-8161
SELECT name
    FROM people
    WHERE phone_number = '(375) 555-8161'; --Find name associated with number (Robin).  Two main suspects are Bruce and Robin
SELECT name
    FROM people
    WHERE passport_number IN
    (SELECT passport_number
        FROM passengers
        WHERE flight_id IN
            (SELECT id
            FROM flights
            WHERE origin_airport_id IN
                (SELECT id
                FROM airports
                WHERE city = 'Fiftyville')
            AND year = 2023
            AND month = 7
            AND day >= 28))
    AND name = 'Bruce'
    OR name = 'Robin'; --Confirming both suspects are on a flight on or past the date of the crime
SELECT name, passport_number
    FROM people
    WHERE name IN ('Bruce', 'Robin'); --Get passport ids so I can figure out which flight they were on, Robin doesn't have a passport number, only need to find destination of Bruce
SELECT city
    FROM airports
    WHERE id IN
    (SELECT destination_airport_id
        FROM flights
        WHERE id IN
            (SELECT flight_id
                FROM passengers
                WHERE passport_number IN
                    (SELECT passport_number
                        FROM people
                        WHERE name = 'Bruce'))); --Get destination city of the flight Bruce was on (New York City)
