text = input("Text: ")
sentence_enders = [".", "?", "!"]
punctuations = sentence_enders + [",", "'", '"',  ";", ":"]
letter_count = 0
word_count = 1
sentence_count = 0


for c in text:
    if c in sentence_enders:
        sentence_count += 1
    elif c not in punctuations and c != " ":
        letter_count += 1
    elif c == " ":
        word_count += 1
if sentence_count == 0:
    sentence_count = 1


CLIndex = 0.0588 * (letter_count * 100 / word_count) - 0.296 * \
    (sentence_count * 100 / word_count) - 15.8
if CLIndex > 16:
    print("Grade: 16+")
elif CLIndex < 1:
    print("Before Grade 1")
else:
    print(f"Grade: {round(CLIndex)}")


