from cs50 import get_int

number = get_int("Number: ")
number_string = str(number)
temp_count = 1
sum_even = 0
sum_odd = 0


for i in range(len(number_string) - 1, -1, -1):
    temp_int = int(number_string[i])
    if temp_count % 2 == 0:
        if (temp_int * 2) > 9 != 0:
            sum_even += 1 + (temp_int * 2) % 10
        else:
            sum_even += temp_int * 2
    else:
        sum_odd += temp_int
    temp_count += 1

sum = sum_odd + sum_even
if sum % 10 == 0:
    if len(number_string) == 15 and (int(number_string[0] + number_string[1]) == 34 or int(number_string[0] + number_string[1]) == 37):
        print("AMEX")
    elif len(number_string) == 16 and (int(number_string[0] + number_string[1]) >= 51 and int(number_string[0] + number_string[1]) <= 55):
        print("MASTERCARD")
    elif (len(number_string) == 16 or len(number_string) == 13) and int(number_string[0]) == 4:
        print("VISA")
    else:
        print("INVALID")
else:
    print("INVALID")

