#include <cs50.h>
#include <stdio.h>
void type(long prefix, int digits);
bool valid(long test_number);
int main(void)
{
    long number = get_long("Number: ");
    long temp = number;
    int digits = 2;
    while (temp >= 100)
    {
        temp = temp / 10;
        digits++;
    }
    long prefix = temp;
    if (valid(number))
    {
        type(prefix, digits);
    }
    else
    {
        printf("INVALID\n");
    }
}

bool valid(long test_number)
{
    int sum1 = 0;
    int sum2 = 0;
    long leftover = test_number;
    while (leftover > 0)
    {
        sum2 += leftover % 10;
        leftover = leftover / 10;
        int temp = (leftover % 10) * 2;
        if (temp > 9)
        {
            sum1 += 1 + (temp % 10);
        }
        else
        {
            sum1 += temp;
        }
        leftover = leftover / 10;
    }
    int sum = sum1 + sum2;
    if (sum % 10 == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}
void type(long prefix, int digits)
{
    if ((prefix == 34 || prefix == 37) && digits == 15)
    {
        printf("AMEX\n");
    }
    else if (prefix <= 55 && prefix >= 51 && digits == 16)
    {
        printf("MASTERCARD\n");
    }
    else if (prefix >= 40 && prefix <= 49 && (digits == 13 || digits == 16))
    {
        printf("VISA\n");
    }
    else
    {
        printf("INVALID\n");
    }
}
