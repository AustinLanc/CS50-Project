#include <cs50.h>
#include <stdio.h>

void block(int a);
int height;
int main(void)
{
    do
    {
        height = get_int("Height: ");
    }
    while (height < 1);
    block(height);
}

void block(int a)
{
    int spacer = a - 1;
    for (int i = 0; i < a; i++)
    {
        for (int j = 0; j < spacer; j++)
        {
            printf(" ");
        }
        for (int k = 0; k <= i; k++)
        {
            printf("#");
        }
        printf("  ");
        for (int k = 0; k <= i; k++)
        {
            printf("#");
        }
        printf("\n");
        spacer--;
    }
}
