#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>

bool test(string s);

int main(int argc, string argv[])
{
    if (argc != 2)
    {
        printf("Please use %s key\n", argv[0]);
        return 1;
    }
    if (test(argv[1]))
    {
        int cipher[26];

        for (int i = 0; i < 26; i++)
        {
            cipher[i] = toupper(argv[1][i]);
        }

        string plaintext = get_string("plaintext: ");
        string ciphertext = plaintext;

        for (int i = 0; i < strlen(plaintext); i++)
        {
            if ((plaintext[i] >= 'A' && plaintext[i] <= 'Z') ||
                (plaintext[i] >= 'a' && plaintext[i] <= 'z'))
            {
                if (isupper(plaintext[i]))
                {
                    ciphertext[i] = cipher[plaintext[i] - 'A'];
                }
                else
                {
                    ciphertext[i] = tolower(cipher[plaintext[i] - 'a']);
                }
            }
            else
            {
                ciphertext[i] = plaintext[i];
            }
        }
        printf("ciphertext: %s\n", ciphertext);
    }
    else
    {
        printf("Not a valid key\n");
        return 1;
    }
}

bool test(string s)
{
    if (strlen(s) == 26)
    {
        int test_array[26] = {0};
        char key[26];
        for (int i = 0; i < 26; i++)
        {
            key[i] = toupper(s[i]);
            if (key[i] >= 'A' && key[i] <= 'Z')
            {
                test_array[key[i] - 'A'] += 1;
            }
            else
            {
                return false;
            }
        }
        for (int i = 0; i < 26; i++)
        {
            if (test_array[i] != 1)
            {
                return false;
            }
        }
        return true;
    }
    else
    {
        return false;
    }
}
