#include <cs50.h>
#include <math.h>
#include <stdio.h>

void get_level(string s);

int main(void)
{
    string text = get_string("Text: ");
    get_level(text);
}
void get_level(string s)
{

    int words = 0;
    int characters = 0;
    int sentences = 0;
    int i = 0;
    while (s[i] != '\0')
    {
        if ((s[i] >= 65 && s[i] <= 90) || (s[i] >= 97 && s[i] <= 122))
        {
            characters++;
        }
        else if ((s[i] == '.' || s[i] == '!' || s[i] == '?') && s[i + 1] != ' ')
        {
            words++;
            sentences++;
        }
        else if (s[i] == '.' || s[i] == '!' || s[i] == '?')
        {
            sentences++;
        }
        else if (s[i] == ' ')
        {
            words++;
        }
        i++;
    }

    int level =
        round(0.0588 * (characters * 100.0 / words) - 0.296 * (sentences * 100.0 / words) - 15.8);
    if (level >= 16)
    {
        level = 16;
        printf("Grade %i+\n", level);
    }
    else if (level < 1)
    {
        printf("Before Grade 1\n");
    }
    else
    {
        printf("Grade %i\n", level);
    }
}
