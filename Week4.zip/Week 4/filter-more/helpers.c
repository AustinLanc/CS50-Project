#include "helpers.h"
#include <math.h>
// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE temp;
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int new_color =
                round((image[i][j].rgbtBlue + image[i][j].rgbtGreen + image[i][j].rgbtRed) / 3.0);
            temp.rgbtBlue = new_color;
            temp.rgbtGreen = new_color;
            temp.rgbtRed = new_color;
            image[i][j] = temp;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE temp;
    int n = width / 2;
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < n; j++)
        {
            temp = image[i][j];
            image[i][j] = image[i][width - j - 1];
            image[i][width - j - 1] = temp;
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE temp_image[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int tempBlue = 0;
            int tempGreen = 0;
            int tempRed = 0;
            int pixel_count = 0;
            for (int a = -1; a <= 1; a++)
            {
                for (int b = -1; b <= 1; b++)
                {
                    if ((i + a < 0 || i + a >= height) || (j + b < 0 || j + b >= width))
                    {
                        continue;
                    }
                    else
                    {
                        pixel_count++;
                        tempBlue += image[i + a][j + b].rgbtBlue;
                        tempGreen += image[i + a][j + b].rgbtGreen;
                        tempRed += image[i + a][j + b].rgbtRed;
                    }
                }
            }

            tempBlue = round((float) tempBlue / pixel_count);
            tempGreen = round((float) tempGreen / pixel_count);
            tempRed = round((float) tempRed / pixel_count);

            temp_image[i][j].rgbtBlue = tempBlue;
            temp_image[i][j].rgbtGreen = tempGreen;
            temp_image[i][j].rgbtRed = tempRed;
        }
    }
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j] = temp_image[i][j];
        }
    }
    return;
}

// Detect edges
void edges(int height, int width, RGBTRIPLE image[height][width])
{
    int Gx[3][3] = {{-1, 0, 1}, {-2, 0, 2}, {-1, 0, 1}};
    int Gy[3][3] = {{-1, -2, -1}, {0, 0, 0}, {1, 2, 1}};
    int tempBlue = 0;
    int tempGreen = 0;
    int tempRed = 0;
    int temp_GxBlue = 0;
    int temp_GyBlue = 0;
    int temp_GxGreen = 0;
    int temp_GyGreen = 0;
    int temp_GxRed = 0;
    int temp_GyRed = 0;
    RGBTRIPLE temp_image[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            tempBlue = 0;
            tempGreen = 0;
            tempRed = 0;
            temp_GxBlue = 0;
            temp_GyBlue = 0;
            temp_GxGreen = 0;
            temp_GyGreen = 0;
            temp_GxRed = 0;
            temp_GyRed = 0;

            for (int a = -1; a <= 1; a++)
            {
                for (int b = -1; b <= 1; b++)
                {
                    if ((i + a < 0 || i + a >= height) || (j + b < 0 || j + b >= width))
                    {
                        continue;
                    }
                    else
                    {
                        temp_GxBlue += image[i + a][j + b].rgbtBlue * Gx[a + 1][b + 1];
                        temp_GyBlue += image[i + a][j + b].rgbtBlue * Gy[a + 1][b + 1];
                        temp_GxGreen += image[i + a][j + b].rgbtGreen * Gx[a + 1][b + 1];
                        temp_GyGreen += image[i + a][j + b].rgbtGreen * Gy[a + 1][b + 1];
                        temp_GxRed += image[i + a][j + b].rgbtRed * Gx[a + 1][b + 1];
                        temp_GyRed += image[i + a][j + b].rgbtRed * Gy[a + 1][b + 1];
                    }
                }
            }

            tempBlue = (sqrt(pow(temp_GxBlue, 2) + pow(temp_GyBlue, 2)) > 255)
                           ? 255
                           : round(sqrt(pow(temp_GxBlue, 2) + pow(temp_GyBlue, 2)));
            tempGreen = (sqrt(pow(temp_GxGreen, 2) + pow(temp_GyGreen, 2)) > 255)
                            ? 255
                            : round(sqrt(pow(temp_GxGreen, 2) + pow(temp_GyGreen, 2)));
            tempRed = (sqrt(pow(temp_GxRed, 2) + pow(temp_GyRed, 2)) > 255)
                          ? 255
                          : round(sqrt(pow(temp_GxRed, 2) + pow(temp_GyRed, 2)));

            temp_image[i][j].rgbtBlue = tempBlue;
            temp_image[i][j].rgbtGreen = tempGreen;
            temp_image[i][j].rgbtRed = tempRed;
        }
    }
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j] = temp_image[i][j];
        }
    }
    return;
}
